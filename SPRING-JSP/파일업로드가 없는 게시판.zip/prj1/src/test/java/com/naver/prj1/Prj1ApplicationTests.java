package com.naver.prj1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prj1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
