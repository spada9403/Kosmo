package com.seahwang.bless;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlessApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlessApplication.class, args);
	}

}
